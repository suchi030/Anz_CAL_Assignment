package Pageobjectrepo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;

public class AnzCalcPageObject {
	
	private WebDriver driver;
	
	public AnzCalcPageObject(WebDriver driver){
		this.driver = driver;
			
	}
	
	
	public By incomebeforetax= By.xpath("//*[contains(text(),'Your income (before tax)')]//following::input");
	public By applicationtypebutton = By.id("application_type_single");
	public By numofdependents_Dropdown_fieldpath=By.xpath("//select[@title='Number of dependants']");
	public By propertytobuy_Button_fieldpath=By.id("borrow_type_home");																															
	public By incomebeforetax_textbox_fieldpath= By.xpath("//*[contains(text(),'Your income (before tax)')]//following::input");
	public By otherincome_textbox_fieldpath=By.xpath("//*[contains(text(),'Your other income')]//following::input");
	public By livingexpense_textbox_fieldpath=By.xpath("//*[contains(text(),'Living expenses')]//following::input");
	public By Currenthomeloanrepayment_textbox_fieldpath=By.xpath("//*[contains(text(),'Current home loan repayments')]//following::input");
	public By otherloansrepayment_textbox_fieldpath=By.xpath("//*[contains(text(),'Other loan repayments')]//following::input");
	public By othercommitments_textbox_fieldpath=By.xpath("//*[contains(text(),'Other commitments')]//following::input");
	public By totalCreditcardlimits_textbox_fieldpath=By.xpath("//*[contains(text(),'Total credit card limits')]//following::input");
	public By howmuchcouldborrow_button_fieldpath=By.id("btnBorrowCalculater");
	public By estimateAmount_textbox_fieldpath=By.xpath("//*[@class='borrow__result__text__amount']");
	public By errortext_textbox_fieldpath=By.xpath("//*[@class='borrow__error__text']");
	public By startover_button_fieldpath=By.xpath("//*[@class='icon icon_restart']");
			
			
		
}
