package TestBase;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import StepDefinitions.Browsers;

//import Pageobjectrepo.AnzAffordabilityCalculatorPageObjects2.Browsers;




public class testbase {

	public  static WebDriver driver;

	
	public static WebDriver selectBrowser(String browser) {
		
		if (browser.equalsIgnoreCase(Browsers.CHROME.name())) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir") + "/src/test/resources/drivers/chromedriver.exe");
			driver = new ChromeDriver();
			driver.manage().window().maximize();
			
		}
	
		 else if (browser.equalsIgnoreCase(Browsers.FIREFOX.name())) {
				System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir") + "/src/test/resources/drivers/geckodriver.exe");
				driver = new FirefoxDriver();
			}
		
		return driver;
	}
}