package StepDefinitions;

public enum Browsers {

	

	CHROME,
	FIREFOX,
	IE

}
